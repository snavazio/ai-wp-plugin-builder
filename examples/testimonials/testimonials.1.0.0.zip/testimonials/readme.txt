=== Testimonials ===
Contributors: stephennavazio
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage client testimonials with ratings, customer details, and admin display.

== Description ==

Manage client testimonials with ratings, customer details, and admin display.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate through the Plugins screen.

== Changelog ==

= 1.0.0 =
* Initial release.
